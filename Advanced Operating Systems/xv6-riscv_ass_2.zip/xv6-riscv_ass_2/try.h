#if 1
    int work(int);
#endif