#include<stdio.h>
#include "try.h"
int main()
{
    work(10);
    return 0;
}

int work(int a)
{
    printf("workd runn %d\n", a);
    return 0;
}