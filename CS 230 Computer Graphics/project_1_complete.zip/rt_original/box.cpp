#include <limits>
#include "box.h"

std::pair<bool,double> Box::Intersection(const Ray& ray) const
{
    double tmin = -std::numeric_limits<double>::infinity();
    double tmax = std::numeric_limits<double>::infinity();

    for (int i = 0; i < 3; ++i) {
        double invDir = 1.0 / ray.direction[i];
        double t0 = (lo[i] - ray.endpoint[i]) * invDir;
        double t1 = (hi[i] - ray.endpoint[i]) * invDir;

        if (invDir < 0.0) std::swap(t0, t1);

        tmin = std::max(tmin, t0);
        tmax = std::min(tmax, t1);

        if (tmin > tmax)
            return {false, 0};
    }

    return {true, tmin};
}

Box Box::Union(const Box& bb) const
{
    Box box;
    for (int i = 0; i < 3; ++i) {
        box.lo[i] = std::min(lo[i], bb.lo[i]);
        box.hi[i] = std::max(hi[i], bb.hi[i]);
    }
    return box;
}

Box Box::Intersection(const Box& bb) const
{
    Box box;
    for (int i = 0; i < 3; ++i) {
        box.lo[i] = std::max(lo[i], bb.lo[i]);
        box.hi[i] = std::min(hi[i], bb.hi[i]);
        if (box.lo[i] > box.hi[i]) {
            box.Make_Empty();
            return box;
        }
    }
    return box;
}

void Box::Include_Point(const vec3& pt)
{
    for (int i = 0; i < 3; ++i) {
        lo[i] = std::min(lo[i], pt[i]);
        hi[i] = std::max(hi[i], pt[i]);
    }
}

void Box::Make_Empty()
{
    lo.fill(std::numeric_limits<double>::infinity());
    hi = -lo;
}

void Box::Make_Full()
{
    hi.fill(std::numeric_limits<double>::infinity());
    lo = -hi;
}

bool Box::Is_Full() const
{
    for (int i = 0; i < 3; ++i) {
        if (lo[i] != -std::numeric_limits<double>::infinity() || hi[i] != std::numeric_limits<double>::infinity())
            return false;
    }
    return true;
}

bool Box::Test_Inside(const vec3& pt) const
{
    for (int i = 0; i < 3; ++i) {
        if (pt[i] < lo[i] || pt[i] > hi[i]) {
            return false;
        }
    }
    return true;
}

std::ostream& operator<<(std::ostream& o, const Box& b)
{
    return o << "(lo: " << b.lo << "; hi: " << b.hi << ")";
}
