#include "parse.h"
#include "texture.h"
#include "dump_png.h"

Texture::Texture(const Parse* parse,std::istream& in)
{
    std::string filename;
    in>>name>>filename>>use_bilinear_interpolation;
    Read_png(data,width,height,filename.c_str());
}

Texture::~Texture()
{
    delete [] data;
}

// uses nearest neighbor interpolation to determine color at texture coordinates
// (uv[0],uv[1]).  To match the reference image, details on how this mapping is
// done will matter.

// 1. Assume that width=5 and height=4.  Texture coordinates with 0<=u<0.2 and
//    0<=v<0.25 should map to pixel index i=0, j=0.  Texture coordinates with
//    0.8<=u<1 and 0.75<=v<1 should map to pixel index i=4, j=3.

// 2. Texture coordinates should "wrap around."  Some of the objects contain
//    (u,v) coordinates that are less than 0 or greater than 1.  u=0.4 and u=1.4
//    and u=-0.6 should be considered equivalent.  There is a wrap function in
//    misc.h that you may use.

// 3. Be very careful about indexing out of bounds.  For example, u=0.999999
//    should result in i=width-1, not i=width.  The latter is out of bounds.

// 4. Be careful with your rounding.  For example, u=-0.0001 should map to
//    i=width-1 in accordance to the wrapping rule.  Remember that casting from
//    float to integer rounds towards zero, so that (int)u would produce 0.  You
//    may find the cmath functions floor, ceil, and rint to be helpful, as they
//    provide precise control over rounding.

// 5. Although there is a flag called use_bilinear_interpolation, none of the
//    test cases exercise this feature.  You do not need to implement it, though
//    of course you are welcome to do so if you like.  You may assume nearest
//    neighbor interpolation.

vec3 Texture::Get_Color(const vec2& uv) const
{
    // TODO;
    // Wrap UV coordinates to be within [0, 1)
    // Wrap UV coordinates to be within [0, 1)
    // std::cout << "uv[0]: " << uv[0] << " uv[1]: " << uv[1] << std::endl;
    double u = uv[0];
    double v = uv[1];

    // std::cout << "u : " << u << " v: " << v << std::endl;
    // Map (u, v) to pixel indices
    // u = -1.01;
    // v = -0.1;
    int i = static_cast<int>(std::floor(u * width)); 
    int j = static_cast<int>(std::floor(v * height));

    // Backup Check
    if(i == width)
    {
        i = width - 1;
    }
    if(j == height)
    {
        j = height - 1;
    }

    // Handle wrapping
    i = wrap(i, width);
    j = wrap(j, height);

    // std::cout << "i: " << i << " j: " << j << " width: " << width << " height: " << height << std::endl;
    // Compute index into the texture data array (1D array representing 2D texture)
    unsigned int index = (j * width + i);  // each pixel has 3 components

    // Fetch the color at the computed index (scaled to [0, 1] range)
    vec3 color = From_Pixel(data[index]);
    // color[0] = data[index];  // Red component
    // color[1] = data[index + 1];  // Green component
    // color[2] = data[index + 2];  // Blue component
    // std::cout << "index: " << index << " width: " << width << " height: " << height << " color: " << color << " total_pixels: " << width*height << std::endl;
    return color;
}
