#include "transparent_shader.h"
#include "parse.h"
#include "ray.h"
#include "render_world.h"

Transparent_Shader::
Transparent_Shader(const Parse* parse,std::istream& in)
{
    in>>name>>index_of_refraction>>opacity;
    shader=parse->Get_Shader(in);
    assert(index_of_refraction>=1.0);
}

// Use opacity to determine the contribution of this->shader and the Schlick
// approximation to compute the reflectivity.  This routine shades transparent
// objects such as glass.  Note that the incoming and outgoing indices of
// refraction depend on whether the ray is entering the object or leaving it.
// You may assume that the object is surrounded by air with index of refraction
// 1.
vec3 Transparent_Shader::
Shade_Surface(const Render_World& render_world,const Ray& ray,const Hit& hit,
    const vec3& intersection_point,const vec3& normal,int recursion_depth) const
{
    // TODO;
    vec3 b_color = shader->Shade_Surface(render_world, ray, hit, intersection_point, normal, recursion_depth);
    if(recursion_depth >= render_world.recursion_depth_limit)
    {
        return (1-opacity) * b_color;
    }
    bool enter_or_exit = dot(ray.direction, normal) < 0;
    vec3 normal_new = enter_or_exit ? normal : -normal;
    vec3 offset_point = intersection_point + small_t * normal_new;
    double n1 = enter_or_exit ? 1.0 : index_of_refraction; // Incoming index of refraction
    double n2 = enter_or_exit ? index_of_refraction : 1.0; // Outgoing index of refraction


    vec3 ray_direction = ray.direction; // Normalized already
    double cos1 = -dot(ray_direction, normal_new);
    cos1 = std::max(-1.0, std::min(1.0, cos1));
    double sin1 = sqrt(1 - cos1 * cos1);

    // Schlick's approximation
    double R0 = pow((n1 - n2) / (n1 + n2), 2);
    double reflectance = R0 + (1 - R0) * pow(1 - cos1, 5);

    // Check for TIR
    double sin2 = (n1 / n2) * sin1;
    // sin2 = std::max(-1.0, std::min(1.0, sin2));
    if(sin2 >= 1.0)
    {
        // TIR happens
        vec3 r = ray_direction - 2 * dot(ray_direction, normal_new) * normal_new;
        Ray reflected_ray(offset_point, r);
        vec3 reflected_color = render_world.Cast_Ray(reflected_ray, recursion_depth + 1);
        // vec3 total_reflection = reflectance * reflected_color + (1.0 - reflectance) * b_color;
        // return (1 - opacity) * b_color + opacity * total_reflection;
        // vec3 background_color = render_world.background_shader ? render_world.background_shader->Shade_Surface(render_world, reflected_ray, hit, intersection_point, normal, recursion_depth) : vec3(0, 0, 0);
        return reflected_color;
    }

    // Refraction Computation
    double cos2 = sqrt(1 - sin2 * sin2);
    cos2 = std::max(0.0, std::min(1.0, cos2)); //Clip
    vec3 refrac_direction = ((n1 / n2) * ray_direction + (((n1 / n2) * cos1) - cos2) * normal_new).normalized();
    vec3 reflec_direction = ray_direction - 2 * dot(ray_direction, normal_new) * normal_new;


    // Cast both reflected and refracted rays
    Ray reflected_ray(offset_point, reflec_direction);
    Ray refracted_ray(offset_point, refrac_direction);
    vec3 reflected_color = render_world.Cast_Ray(reflected_ray, recursion_depth + 1);
    vec3 refracted_color = render_world.Cast_Ray(refracted_ray, recursion_depth + 1);

    // Total color
    vec3 transparent_color = reflectance * reflected_color + (1.0 - reflectance) * refracted_color;
    vec3 total_color = (1 - opacity) * b_color + opacity * transparent_color;
    return total_color;
}
