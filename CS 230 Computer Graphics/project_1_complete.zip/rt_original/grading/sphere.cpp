// Mohit Akerkar
#include "sphere.h"
#include "ray.h"

Sphere::Sphere(const Parse* parse, std::istream& in)
{
    in>>name>>center>>radius;
}

// Determine if the ray intersects with the sphere
Hit Sphere::Intersection(const Ray& ray, int part) const
{
    // TODO;
    vec3 z = ray.endpoint - center;
    double a = dot(ray.direction, ray.direction);
    double b = 2.0 * dot(ray.direction, z);
    double c = dot(z, z) - radius * radius;

    // Discriminant
    double d = b * b - 4 * a * c;
    if(d < 0)
    {
        // No intersection
        return Hit{};
    }
    double sq_d = sqrt(d);
    // double r1 = (-b + sq_d) / (2.0 * a);
    double r2 = (-b - sq_d) / (2.0 * a);

    // if(r1 > 0)
    // {
    //     return Hit{r1};
    // }
    // else if(r2 > 0)
    // {
    //     return Hit{r2};
    // }
    
    return Hit({r2}); // No valid intersection
}

vec3 Sphere::Normal(const Ray& ray, const Hit& hit) const
{
    vec3 point = ray.Point(hit.dist);
    vec3 normal = (point - center) / radius; //normalized the direction vector
    // TODO; // compute the normal direction
    return normal;
}

std::pair<Box,bool> Sphere::Bounding_Box(int part) const
{
    return {{center-radius,center+radius},false};
}
