#include "render_world.h"
#include "flat_shader.h"
#include "object.h"
#include "light.h"
#include "ray.h"

extern bool enable_acceleration;

Render_World::~Render_World()
{
    for(auto a:all_objects) delete a;
    for(auto a:all_shaders) delete a;
    for(auto a:all_colors) delete a;
    for(auto a:lights) delete a;
}

// Find and return the Hit structure for the closest intersection.  Be careful
// to ensure that hit.dist>=small_t.
std::pair<Shaded_Object,Hit> Render_World::Closest_Intersection(const Ray& ray) const
{
    //TODO;
    Shaded_Object closest;
    Hit closest_hit;
    for(long unsigned int i=0; i<objects.size(); i++)
    {
        for(int j=0; j<objects[i].object->num_parts; j++)
        {
            Hit hit = objects[i].object->Intersection(ray, j);
            if(hit.dist>=small_t)
            {
                if(closest_hit.dist == -1)
                {
                    closest=objects[i];
                    closest_hit=hit;
                    // std::cout << " since closest hit is -1, now replaced with closest_hit: " << closest_hit << std::endl;
                }
                else if(hit.dist<closest_hit.dist)
                {
                    closest=objects[i];
                    closest_hit=hit;
                    // std::cout << "replaced with closest_hit: " << closest_hit << std::endl;
                }
            }
        }
    }
    if(closest_hit.dist >= small_t)
    {
        return {closest, closest_hit};
    }
    else
    {
        return {Shaded_Object{}, Hit({-1})};
    }
}

// set up the initial view ray and call
void Render_World::Render_Pixel(const ivec2& pixel_index)
{
    // TODO; // set up the initial view ray here
    Ray ray;
    ray.endpoint = camera.position;
    vec3 wp = camera.World_Position(pixel_index);
    ray.direction = (wp - ray.endpoint).normalized();
    vec3 color=Cast_Ray(ray,1);
    camera.Set_Pixel(pixel_index,Pixel_Color(color));
}

void Render_World::Render()
{
    for(int j=0;j<camera.number_pixels[1];j++)
        for(int i=0;i<camera.number_pixels[0];i++)
            Render_Pixel(ivec2(i,j));
}

// cast ray and return the color of the closest intersected surface point,
// or the background color if there is no object intersection
vec3 Render_World::Cast_Ray(const Ray& ray,int recursion_depth) const
{
    vec3 color;
    // TODO; // determine the color here
    auto shaded_object_and_hit = Closest_Intersection(ray);
    if(shaded_object_and_hit.second.dist >= small_t)
    {
        vec3 point = ray.Point(shaded_object_and_hit.second.dist); // closest intersection point
        vec3 normal = shaded_object_and_hit.first.object->Normal(ray, shaded_object_and_hit.second); // normal at intersection point
        color = shaded_object_and_hit.first.shader->Shade_Surface(*this, ray, shaded_object_and_hit.second, point, normal, recursion_depth);
    }
    else
    {
        if(background_shader)
        {
            color = background_shader->Shade_Surface(*this, ray, Hit({-1}), vec3(0, 0, 0), vec3(0, 0, 0), recursion_depth);
        }
        else
        {
            color = vec3{0, 0, 0};
        }
    }
    return color;
}
