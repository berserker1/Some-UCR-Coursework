#include "reflective_shader.h"
#include "parse.h"
#include "ray.h"
#include "render_world.h"

Reflective_Shader::Reflective_Shader(const Parse* parse,std::istream& in)
{
    in>>name;
    shader=parse->Get_Shader(in);
    in>>reflectivity;
    reflectivity=std::max(0.0,std::min(1.0,reflectivity));
}

vec3 Reflective_Shader::
Shade_Surface(const Render_World& render_world,const Ray& ray,const Hit& hit,
    const vec3& intersection_point,const vec3& normal,int recursion_depth) const
{
    // TODO; // determine the color
    vec3 s_color, r_color;
    vec3 ray_direction;
    s_color = shader->Shade_Surface(render_world, ray, hit, intersection_point, normal, recursion_depth);
    ray_direction = (ray.direction - 2 * dot(ray.direction, normal) * normal).normalized();
    Ray r(intersection_point, ray_direction); // reflected ray
    if(recursion_depth >= render_world.recursion_depth_limit)
    {
        return (1-reflectivity) * s_color;
    }
    r_color = render_world.Cast_Ray(r, recursion_depth + 1);
    s_color = (1-reflectivity) * s_color + reflectivity * r_color;
    return s_color;
}
