//Aaryan Bhagat
#include "light.h"
#include "parse.h"
#include "object.h"
#include "phong_shader.h"
#include "ray.h"
#include "render_world.h"

Phong_Shader::Phong_Shader(const Parse* parse,std::istream& in)
{
    in>>name;
    color_ambient=parse->Get_Color(in);
    color_diffuse=parse->Get_Color(in);
    color_specular=parse->Get_Color(in);
    in>>specular_power;
}

vec3 Phong_Shader::
Shade_Surface(const Render_World& render_world,const Ray& ray,const Hit& hit,
    const vec3& intersection_point,const vec3& normal,int recursion_depth) const
{
    vec3 color, diffuse_light, ambient_light, specular_light;
    color = vec3(0, 0, 0); // Initialize color to black
    vec3 ambient;
    // double max_t = std::numeric_limits<int>::max();
    if(render_world.ambient_color)
    {
        color = render_world.ambient_color->Get_Color(vec2(0, 0)) * render_world.ambient_intensity * color_ambient->Get_Color(hit.uv);
    }
    // TODO; //determine the color
    // Iterating through all the lights in the scene
    for(const Light* light : render_world.lights)
    {
        // Computer direction from point to light
        vec3 l = (light->position - intersection_point).normalized();
        vec3 light_color = light->Emitted_Light((light->position - intersection_point));
        // vec3 ldir = (light->position - intersection_point);
        // Check for shadows
        double light_distance = (light->position - intersection_point).magnitude();
        if(render_world.enable_shadows)
        {
            Ray shadow_ray(intersection_point, l);
            auto [shadow_object, shadow_hit] = render_world.Closest_Intersection(shadow_ray);
            if(shadow_hit.Valid() && (shadow_hit.dist < light_distance) && (shadow_hit.dist > small_t))
            {
                continue;
            }
        }
        //Diffuse Lighting
        double diffuse_intensity = std::max(0.0, dot(normal, l));
        if(diffuse_intensity)
        {
            // Color of light and object
            color += diffuse_intensity * light_color * color_diffuse->Get_Color(hit.uv);
        }
        // Specular Lighting
        // vec3 view_dir = (render_world.camera.position - intersection_point).normalized();
        vec3 reflect_dir = (normal * 2.0 * dot(normal, l) - l).normalized();
        double m = dot(-ray.direction, reflect_dir);
        m = m>=0 ? m : 0; // Clamped
        m = pow(m,specular_power);
        double specular_intensity = m;

        if (m > 0)
        {
            color += specular_intensity * light_color * color_specular->Get_Color(hit.uv);
        }
    }
    color += ambient;
    return color;
}
