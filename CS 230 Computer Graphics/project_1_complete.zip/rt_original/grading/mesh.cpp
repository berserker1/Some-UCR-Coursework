// Mohit
#include "mesh.h"
#include <fstream>
#include <limits>
#include <string>
#include <algorithm>

// Consider a triangle to intersect a ray if the ray intersects the plane of the
// triangle with barycentric weights in [-weight_tolerance, 1+weight_tolerance]
static const double weight_tolerance = 1e-4;

Mesh::Mesh(const Parse* parse, std::istream& in)
{
    std::string file;
    in>>name>>file;
    Read_Obj(file.c_str());
}

// Read in a mesh from an obj file.  Populates the bounding box and registers
// one part per triangle (by setting number_parts).
void Mesh::Read_Obj(const char* file)
{
    std::ifstream fin(file);
    if(!fin)
    {
        exit(EXIT_FAILURE);
    }
    std::string line;
    ivec3 e, t;
    vec3 v;
    vec2 u;
    while(fin)
    {
        getline(fin,line);

        if(sscanf(line.c_str(), "v %lg %lg %lg", &v[0], &v[1], &v[2]) == 3)
        {
            vertices.push_back(v);
        }

        if(sscanf(line.c_str(), "f %d %d %d", &e[0], &e[1], &e[2]) == 3)
        {
            for(int i=0;i<3;i++) e[i]--;
            triangles.push_back(e);
        }

        if(sscanf(line.c_str(), "vt %lg %lg", &u[0], &u[1]) == 2)
        {
            uvs.push_back(u);
        }

        if(sscanf(line.c_str(), "f %d/%d %d/%d %d/%d", &e[0], &t[0], &e[1], &t[1], &e[2], &t[2]) == 6)
        {
            for(int i=0;i<3;i++) e[i]--;
            triangles.push_back(e);
            for(int i=0;i<3;i++) t[i]--;
            triangle_texture_index.push_back(t);
        }
    }
    num_parts=triangles.size();
}

// Check for an intersection against the ray.  See the base class for details.
Hit Mesh::Intersection(const Ray& ray, int part) const
{
    Hit hit;
    hit.dist = std::numeric_limits<double>::max();

    if (part >= 0)
    {
        hit = Intersect_Triangle(ray, part);
        if (hit.Valid())
        {
            hit.triangle = part;
        }
    }
    else
    {
        for (long unsigned int i = 0; i < triangles.size(); i++)
        {
            Hit tmp = Intersect_Triangle(ray, i);
            if (tmp.Valid() && tmp.dist < hit.dist)
            {
                hit = tmp;
                hit.triangle = i;
            }
        }
    }

    // Ensure we only return valid intersections.
    if (hit.dist  == std::numeric_limits<double>::max())
    {
        return Hit({-1});
    }

    return hit;
}


// Compute the normal direction for the triangle with index part.
vec3 Mesh::Normal(const Ray& ray, const Hit& hit) const
{
    assert(hit.triangle>=0);
    // TODO;
    ivec3 e = triangles[hit.triangle];
    vec3 a0 = vertices[e[0]];
    vec3 a1 = vertices[e[1]];
    vec3 a2 = vertices[e[2]];
    // Compute normal vector and normalize it
    vec3 n = cross(a1 - a0, a2 - a0).normalized();
    return n;
    // return {};
}

// This is a helper routine whose purpose is to simplify the implementation
// of the Intersection routine.  It should test for an intersection between
// the ray and the triangle with index tri.  If an intersection exists,
// record the distance and return true.  Otherwise, return false.
// This intersection should be computed by determining the intersection of
// the ray and the plane of the triangle.  From this, determine (1) where
// along the ray the intersection point occurs (dist) and (2) the barycentric
// coordinates within the triangle where the intersection occurs.  The
// triangle intersects the ray if dist>small_t and the barycentric weights are
// larger than -weight_tolerance.  The use of small_t avoid the self-shadowing
// bug, and the use of weight_tolerance prevents rays from passing in between
// two triangles.
Hit Mesh::Intersect_Triangle(const Ray& ray, int tri) const
{
    Hit hit;
    // Triangle vertices
    ivec3 current_triangle = triangles[tri];
    vec3 A = vertices[current_triangle[0]];
    vec3 B = vertices[current_triangle[1]];
    vec3 C = vertices[current_triangle[2]];

    vec3 rd = ray.direction.normalized();
    vec3 BA = B - A;
    vec3 CA = C - A;
    vec3 epA = ray.endpoint - A;

    double denom = dot(cross(rd, BA), CA);
    if (fabs(denom) < std::numeric_limits<double>::epsilon())
    {
        return Hit({-1});
    }
    double t = -(dot(cross(BA, CA),epA)) / (dot(cross(BA, CA),rd));
    double beta, gamma;
    if (t >= small_t)
    {
        beta = dot(cross(CA, rd), epA) / denom;
        gamma = dot(cross(rd, BA), epA) / denom;
        if ((beta > (-weight_tolerance)) && (gamma > (-weight_tolerance)) && ((1 - gamma - beta) > (-weight_tolerance)))
        {
            // check less than condition
            if((beta < (1 + weight_tolerance)) && (gamma < (1 + weight_tolerance)) && ((1 - gamma - beta) < (1 + weight_tolerance)))
            {
                hit.dist = t;
                double alpha = 1 - beta - gamma;
                if (!triangle_texture_index.empty())
                {
                    const ivec3& tex_idx = triangle_texture_index[tri];
                    vec2 uv_a = uvs[tex_idx[0]];
                    vec2 uv_b = uvs[tex_idx[1]];
                    vec2 uv_c = uvs[tex_idx[2]];
                    double tex_u = alpha * uv_a[0] + beta * uv_b[0] + gamma * uv_c[0];
                    double tex_v = alpha * uv_a[1] + beta * uv_b[1] + gamma * uv_c[1];
                    // std::cout << "tex_u: " << tex_u << " tex_v: " << tex_v << std::endl;
                    hit.uv = {tex_u, tex_v};  // texture coordinates
                }
                return hit;
            }
        }
    }

    return Hit({-1});  // No valid intersection
}

std::pair<Box,bool> Mesh::Bounding_Box(int part) const
{
    if(part<0)
    {
        Box box;
        box.Make_Empty();
        for(const auto& v:vertices)
            box.Include_Point(v);
        return {box,false};
    }

    ivec3 e=triangles[part];
    vec3 A=vertices[e[0]];
    Box b={A,A};
    b.Include_Point(vertices[e[1]]);
    b.Include_Point(vertices[e[2]]);
    return {b,false};
}
