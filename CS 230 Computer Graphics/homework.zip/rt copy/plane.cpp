// Aaryan Bhagat
#include "plane.h"
#include "hit.h"
#include "ray.h"
#include <cfloat>
#include <limits>

Plane::Plane(const Parse* parse,std::istream& in)
{
    in>>name>>x>>normal;
    normal=normal.normalized();
}

// Intersect with the plane.  The plane's normal points outside.
Hit Plane::Intersection(const Ray& ray, int part) const
{
    // TODO;
    double d = dot(normal, ray.direction);
    if(fabs(d) < std::numeric_limits<double>::epsilon())
    {
        return Hit{};
    }
    double n = dot(normal, x - ray.endpoint);
    double f = n / d;
    if(f < 0)
    {
        return Hit{};
    }
    if(f >= small_t)
    {
        Hit hit;
        hit.dist = f;
        return hit;
    }
    return Hit{f};
}

vec3 Plane::Normal(const Ray& ray, const Hit& hit) const
{
    return normal;
}

std::pair<Box,bool> Plane::Bounding_Box(int part) const
{
    Box b;
    b.Make_Full();
    return {b,true};
}
