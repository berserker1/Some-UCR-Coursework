// Mohit
#include "mesh.h"
#include <fstream>
#include <limits>
#include <string>
#include <algorithm>

// Consider a triangle to intersect a ray if the ray intersects the plane of the
// triangle with barycentric weights in [-weight_tolerance, 1+weight_tolerance]
static const double weight_tolerance = 1e-4;

Mesh::Mesh(const Parse* parse, std::istream& in)
{
    std::string file;
    in>>name>>file;
    Read_Obj(file.c_str());
}

// Read in a mesh from an obj file.  Populates the bounding box and registers
// one part per triangle (by setting number_parts).
void Mesh::Read_Obj(const char* file)
{
    std::ifstream fin(file);
    if(!fin)
    {
        exit(EXIT_FAILURE);
    }
    std::string line;
    ivec3 e, t;
    vec3 v;
    vec2 u;
    while(fin)
    {
        getline(fin,line);

        if(sscanf(line.c_str(), "v %lg %lg %lg", &v[0], &v[1], &v[2]) == 3)
        {
            vertices.push_back(v);
        }

        if(sscanf(line.c_str(), "f %d %d %d", &e[0], &e[1], &e[2]) == 3)
        {
            for(int i=0;i<3;i++) e[i]--;
            triangles.push_back(e);
        }

        if(sscanf(line.c_str(), "vt %lg %lg", &u[0], &u[1]) == 2)
        {
            uvs.push_back(u);
        }

        if(sscanf(line.c_str(), "f %d/%d %d/%d %d/%d", &e[0], &t[0], &e[1], &t[1], &e[2], &t[2]) == 6)
        {
            for(int i=0;i<3;i++) e[i]--;
            triangles.push_back(e);
            for(int i=0;i<3;i++) t[i]--;
            triangle_texture_index.push_back(t);
        }
    }
    num_parts=triangles.size();
}

// Check for an intersection against the ray.  See the base class for details.
Hit Mesh::Intersection(const Ray& ray, int part) const
{
    // TODO;
    Hit hit;
    // double tri = 0;
    // double min_t = std::numeric_limits<double>::max();
    if(Intersect_Triangle(ray, part).dist)
    {
        hit = Intersect_Triangle(ray, part);
        hit.triangle = part;
        return hit;
    }
    return Hit({-1});
}

// Compute the normal direction for the triangle with index part.
vec3 Mesh::Normal(const Ray& ray, const Hit& hit) const
{
    assert(hit.triangle>=0);
    // TODO;
    ivec3 e = triangles[hit.triangle];
    vec3 a0 = vertices[e[0]];
    vec3 a1 = vertices[e[1]];
    vec3 a2 = vertices[e[2]];
    // Compute normal vector and normalize it
    vec3 n = cross(a1 - a0, a2 - a0).normalized();
    return n;
}

// This is a helper routine whose purpose is to simplify the implementation
// of the Intersection routine.  It should test for an intersection between
// the ray and the triangle with index tri.  If an intersection exists,
// record the distance and return true.  Otherwise, return false.
// This intersection should be computed by determining the intersection of
// the ray and the plane of the triangle.  From this, determine (1) where
// along the ray the intersection point occurs (dist) and (2) the barycentric
// coordinates within the triangle where the intersection occurs.  The
// triangle intersects the ray if dist>small_t and the barycentric weights are
// larger than -weight_tolerance.  The use of small_t avoid the self-shadowing
// bug, and the use of weight_tolerance prevents rays from passing in between
// two triangles.
Hit Mesh::Intersect_Triangle(const Ray& ray, int tri) const
{
    // TODO;
    ivec3 e = triangles[tri];
    vec3 a0 = vertices[e[0]];
    vec3 a1 = vertices[e[1]];
    vec3 a2 = vertices[e[2]];

    vec3 ab = a1 - a0;
    vec3 ac = a2 - a0;

    vec3 normal = cross(ab, ac).normalized();
    double denom = dot(ray.direction, normal);

    // If a is near zero, the ray is parallel to the triangle
    if(fabs(denom) < std::numeric_limits<double>::epsilon())
    {
        return Hit({-1});
    }
    vec3 O = ray.endpoint - a0;
    double t =  dot(O, normal) / denom;
    if(t < small_t)
    {
        return Hit({-1});
    }

    vec3 p = ray.endpoint + t * ray.direction;  // Point of intersection
    vec3 ap = p - a0;
    vec3 bp = p - a1;
    vec3 cp = p - a2;

    vec3 cross_1 = cross(ab, ap);
    vec3 cross_2 = cross(a2 - a1, bp);
    vec3 cross_3 = cross(a0 - a2, cp);

    double alpha = dot(normal, cross_1);
    double beta = dot(normal, cross_2);
    double gamma = dot(normal, cross_3);
    if(alpha >= -weight_tolerance && beta >= -weight_tolerance && gamma >= -weight_tolerance &&
        alpha + beta + gamma <= 1 + weight_tolerance)
    {
        // If the intersection is inside the triangle, return the hit info
        Hit hit;
        hit.dist = t;  // Set the intersection distance
        hit.triangle = tri;  // Set the triangle index

        // Triangle has texture coordinates (check if triangle_texture_index exists)
        if (!triangle_texture_index.empty())
        {
            // Get the texture indices for the current triangle
            const ivec3& tex_idx = triangle_texture_index[tri];
            
            // Interpolate UV coordinates at the intersection point using barycentric coordinates
            double u = alpha * uvs[tex_idx[0]][0] + beta * uvs[tex_idx[1]][0] + gamma * uvs[tex_idx[2]][0];
            double v = alpha * uvs[tex_idx[0]][1] + beta * uvs[tex_idx[1]][1] + gamma * uvs[tex_idx[2]][1];
            
            hit.uv = {u, v};  // Set the UV coordinates for the hit
        }
        return hit;
    }

    return Hit({-1});
}

std::pair<Box,bool> Mesh::Bounding_Box(int part) const
{
    if(part<0)
    {
        Box box;
        box.Make_Empty();
        for(const auto& v:vertices)
            box.Include_Point(v);
        return {box,false};
    }

    ivec3 e=triangles[part];
    vec3 A=vertices[e[0]];
    Box b={A,A};
    b.Include_Point(vertices[e[1]]);
    b.Include_Point(vertices[e[2]]);
    return {b,false};
}
